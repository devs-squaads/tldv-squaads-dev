// src/shared/constants.ts
var DEFAULT_SETTINGS = {
  apiBaseUrl: "",
  apiToken: "",
  connectionToken: "",
  extensionAccessToken: "",
  extensionAccessTokenExpiresAt: "",
  linkedAccountEmail: "",
  connectedAt: "",
  defaultBotName: "Squaads Assistant",
  defaultDurationMinutes: 60
};
var REQUEST_TIMEOUT_MS = 1e4;

// src/shared/storage.ts
async function getSettings() {
  const result = await chrome.storage.sync.get([
    "apiBaseUrl",
    "apiToken",
    "connectionToken",
    "extensionAccessToken",
    "extensionAccessTokenExpiresAt",
    "linkedAccountEmail",
    "connectedAt",
    "defaultBotName",
    "defaultDurationMinutes"
  ]);
  return {
    apiBaseUrl: result.apiBaseUrl || DEFAULT_SETTINGS.apiBaseUrl,
    apiToken: result.apiToken || DEFAULT_SETTINGS.apiToken,
    connectionToken: result.connectionToken || DEFAULT_SETTINGS.connectionToken,
    extensionAccessToken: result.extensionAccessToken || DEFAULT_SETTINGS.extensionAccessToken,
    extensionAccessTokenExpiresAt: result.extensionAccessTokenExpiresAt || DEFAULT_SETTINGS.extensionAccessTokenExpiresAt,
    linkedAccountEmail: result.linkedAccountEmail || DEFAULT_SETTINGS.linkedAccountEmail,
    connectedAt: result.connectedAt || DEFAULT_SETTINGS.connectedAt,
    defaultBotName: result.defaultBotName || DEFAULT_SETTINGS.defaultBotName,
    defaultDurationMinutes: result.defaultDurationMinutes || DEFAULT_SETTINGS.defaultDurationMinutes
  };
}
async function saveSettings(settings) {
  await chrome.storage.sync.set({
    apiBaseUrl: settings.apiBaseUrl.trim().replace(/\/$/, ""),
    apiToken: settings.apiToken.trim(),
    connectionToken: settings.connectionToken.trim(),
    extensionAccessToken: settings.extensionAccessToken.trim(),
    extensionAccessTokenExpiresAt: settings.extensionAccessTokenExpiresAt,
    linkedAccountEmail: settings.linkedAccountEmail.trim(),
    connectedAt: settings.connectedAt,
    defaultBotName: settings.defaultBotName.trim() || DEFAULT_SETTINGS.defaultBotName,
    defaultDurationMinutes: settings.defaultDurationMinutes || DEFAULT_SETTINGS.defaultDurationMinutes
  });
}

// src/shared/meeting-url.ts
function detectMeetingProvider(url) {
  const lower = url.toLowerCase();
  if (lower.includes("meet.google.com"))
    return "google-meet";
  if (lower.includes("teams.microsoft.com"))
    return "microsoft-teams";
  if (lower.includes("zoom.us") || lower.includes(".zoom.com"))
    return "zoom";
  return null;
}
function normalizeMeetingUrl(url, provider) {
  try {
    const parsed = new URL(url.trim());
    parsed.hash = "";
    if (provider === "google-meet") {
      const match = parsed.href.match(/https:\/\/meet\.google\.com\/[a-z]{3}-[a-z]{4}-[a-z]{3}/i);
      return match ? match[0].toLowerCase() : null;
    }
    parsed.protocol = "https:";
    parsed.hostname = parsed.hostname.toLowerCase();
    parsed.pathname = parsed.pathname.replace(/\/+$/, "");
    return parsed.toString();
  } catch {
    return null;
  }
}

// src/shared/origin.ts
function normalizeOrigin(input) {
  try {
    const parsed = new URL(input.trim());
    const protocol = parsed.protocol.toLowerCase();
    const hostname = parsed.hostname.toLowerCase();
    const port = parsed.port;
    const isDefaultPort = protocol === "https:" && port === "443" || protocol === "http:" && port === "80";
    const host = port && !isDefaultPort ? `${hostname}:${port}` : hostname;
    return `${protocol}//${host}`;
  } catch {
    return "";
  }
}
function getConnectableSiteContext(url) {
  if (!url) {
    return {
      origin: "",
      eligible: false,
      reason: "Open the Squaads dashboard tab where you generated the token, then try again."
    };
  }
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return {
      origin: "",
      eligible: false,
      reason: "This tab cannot be used for connection. Open the Squaads dashboard first."
    };
  }
  if (!["http:", "https:"].includes(parsed.protocol)) {
    return {
      origin: "",
      eligible: false,
      reason: "Only a Squaads web tab can finish connection. Browser internal pages are not supported."
    };
  }
  const provider = detectMeetingProvider(url);
  if (provider && normalizeMeetingUrl(url, provider)) {
    return {
      origin: "",
      eligible: false,
      reason: "You are on a meeting tab. Return to the Squaads dashboard tab where you generated the token."
    };
  }
  if (parsed.hostname === "chromewebstore.google.com" || parsed.hostname === "chrome.google.com" && parsed.pathname.startsWith("/webstore")) {
    return {
      origin: "",
      eligible: false,
      reason: "Return to the Squaads dashboard tab after visiting the Chrome Web Store."
    };
  }
  const origin = normalizeOrigin(parsed.toString());
  return {
    origin,
    eligible: Boolean(origin),
    reason: origin ? `Current site ready: ${origin}` : "Open the Squaads dashboard tab before connecting."
  };
}

// src/shared/logger.ts
var PREFIX = "[squaads-ext]";
function logInfo(message, meta) {
  if (meta !== undefined) {
    console.log(`${PREFIX} ${message}`, meta);
    return;
  }
  console.log(`${PREFIX} ${message}`);
}
function logError(message, meta) {
  if (meta !== undefined) {
    console.error(`${PREFIX} ${message}`, meta);
    return;
  }
  console.error(`${PREFIX} ${message}`);
}

// src/background/api-client.ts
function isExpired(isoTimestamp) {
  if (!isoTimestamp)
    return false;
  const parsed = Date.parse(isoTimestamp);
  if (Number.isNaN(parsed))
    return false;
  return parsed <= Date.now();
}
function mapApiError(status, text) {
  if (status === 401) {
    if (/expired link token/i.test(text))
      return "This connection token expired. Go back to the Squaads dashboard and generate a new one.";
    if (/expired extension access token/i.test(text))
      return "Your secure extension session expired. Reconnect it from the Squaads dashboard.";
    if (/invalid or expired extension access token/i.test(text))
      return "Your secure extension session expired. Reconnect it from the Squaads dashboard.";
    if (/invalid or expired link token/i.test(text))
      return "This connection token is invalid or expired. Generate a new one from the dashboard.";
    return "Unauthorized. Verify extension connection or legacy API token.";
  }
  if (status === 403) {
    if (/origin mismatch/i.test(text))
      return "Wrong site for this token. Open the same Squaads dashboard tab where you generated it and try again.";
    return "Forbidden by server.";
  }
  if (status === 404)
    return "Endpoint not found. Verify API base URL.";
  if (status >= 500)
    return "Server error. Please check backend logs.";
  return `API ${status}: ${text}`;
}
async function resolveTransport(path) {
  let settings = await getSettings();
  const apiBaseUrl = settings.apiBaseUrl;
  if (!apiBaseUrl) {
    throw new Error("Extension not configured. Open Configuration and connect it first.");
  }
  if (settings.extensionAccessToken) {
    if (isExpired(settings.extensionAccessTokenExpiresAt)) {
      settings = {
        ...settings,
        connectionToken: "",
        extensionAccessToken: "",
        extensionAccessTokenExpiresAt: "",
        linkedAccountEmail: "",
        connectedAt: ""
      };
      await saveSettings(settings);
      if (!settings.apiToken) {
        throw new Error("Secure extension session expired. Reconnect it from the Squaads dashboard.");
      }
    }
  }
  if (settings.extensionAccessToken) {
    return {
      apiBaseUrl,
      token: settings.extensionAccessToken,
      authMode: "linked-session",
      path: path.replace("/api/", "/api/v1/extension/")
    };
  }
  if (settings.apiToken) {
    return {
      apiBaseUrl,
      token: settings.apiToken,
      authMode: "legacy-token",
      path
    };
  }
  throw new Error("Extension not configured. Connect it with a secure token or add a legacy API token.");
}
async function apiFetch(path, init = {}) {
  const transport = await resolveTransport(path);
  const controller = new AbortController;
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(`${transport.apiBaseUrl}${transport.path}`, {
      ...init,
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${transport.token}`,
        ...init.headers || {}
      }
    });
    if (!response.ok) {
      const text = await response.text().catch(() => response.statusText);
      throw new Error(mapApiError(response.status, text));
    }
    return await response.json();
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") {
      throw new Error("Server timeout after 10s. Verify backend is reachable.");
    }
    logError("apiFetch failed", error);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}
async function connectExtension(apiBaseUrl, linkToken) {
  const controller = new AbortController;
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(`${apiBaseUrl.replace(/\/$/, "")}/api/v1/extension/connect`, {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ linkToken })
    });
    if (!response.ok) {
      const text = await response.text().catch(() => response.statusText);
      throw new Error(mapApiError(response.status, text));
    }
    return await response.json();
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") {
      throw new Error("Server timeout after 10s. Verify backend is reachable.");
    }
    logError("connectExtension failed", error);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}
async function checkStatus(meetingUrl, provider) {
  logInfo("checkStatus", { provider, meetingUrl });
  return apiFetch(`/api/meetings/status?url=${encodeURIComponent(meetingUrl)}&provider=${encodeURIComponent(provider)}`);
}
async function inviteBot(meetingUrl, provider, botName, duration) {
  logInfo("inviteBot", { provider, meetingUrl });
  const payload = await apiFetch("/api/bot/start", {
    method: "POST",
    body: JSON.stringify({
      meetingUrl,
      provider,
      botName,
      duration
    })
  });
  const first = payload.results[0];
  if (!first)
    throw new Error("Invalid start response.");
  if (!first.queued || !first.meetingId) {
    throw new Error(first.error || "Bot was not queued.");
  }
  return {
    meetingId: first.meetingId,
    queued: first.queued,
    provider: first.provider,
    normalizedUrl: first.url
  };
}
async function pollMeeting(meetingId) {
  return apiFetch(`/api/meetings/${meetingId}`);
}

// src/background/service-worker.ts
function isMeetingUrl(url) {
  if (!url)
    return false;
  const provider = detectMeetingProvider(url);
  if (!provider)
    return false;
  return Boolean(normalizeMeetingUrl(url, provider));
}
async function clearBadgeIfNoMeetingTabs() {
  const tabs = await chrome.tabs.query({});
  const hasMeetingTab = tabs.some((tab) => isMeetingUrl(tab.url));
  if (!hasMeetingTab) {
    setBadge("clear");
  }
}
function setBadge(state) {
  if (state === "recording") {
    chrome.action.setBadgeText({ text: "REC" });
    chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
    return;
  }
  if (state === "error") {
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
    return;
  }
  chrome.action.setBadgeText({ text: "" });
}
async function handleMessage(message) {
  logInfo("runtime message", { type: message.type });
  switch (message.type) {
    case "GET_SETTINGS":
      return { ok: true, data: await getSettings() };
    case "SAVE_SETTINGS": {
      const merged = {
        ...DEFAULT_SETTINGS,
        ...message.settings
      };
      await saveSettings(merged);
      return { ok: true };
    }
    case "CONNECT_EXTENSION": {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const manualBaseUrl = message.apiBaseUrl?.trim();
      const connectContext = getConnectableSiteContext(tab?.url);
      const apiBaseUrl = manualBaseUrl || connectContext.origin;
      if (!manualBaseUrl && !connectContext.eligible) {
        return { ok: false, error: connectContext.reason };
      }
      if (!apiBaseUrl) {
        return { ok: false, error: "Open the Squaads dashboard tab before connecting the extension." };
      }
      const connection = await connectExtension(apiBaseUrl, message.linkToken);
      const current = await getSettings();
      await saveSettings({
        ...current,
        apiBaseUrl: connection.apiBaseUrl,
        connectionToken: "",
        extensionAccessToken: connection.extensionAccessToken,
        extensionAccessTokenExpiresAt: connection.expiresAt,
        linkedAccountEmail: connection.linkedAccountEmail,
        connectedAt: new Date().toISOString()
      });
      return { ok: true, data: connection };
    }
    case "CHECK_STATUS":
      return { ok: true, data: await checkStatus(message.meetingUrl, message.provider) };
    case "INVITE_BOT": {
      const settings = await getSettings();
      const botName = message.botName || settings.defaultBotName || DEFAULT_SETTINGS.defaultBotName;
      const duration = message.duration || settings.defaultDurationMinutes || DEFAULT_SETTINGS.defaultDurationMinutes;
      return {
        ok: true,
        data: await inviteBot(message.meetingUrl, message.provider, botName, duration)
      };
    }
    case "POLL_MEETING":
      return { ok: true, data: await pollMeeting(message.meetingId) };
    case "SET_BADGE":
      setBadge(message.state);
      return { ok: true };
    default:
      return { ok: false, error: "Unknown runtime message." };
  }
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message).then((res) => sendResponse(res)).catch((error) => {
    logError("runtime message failed", error);
    const text = error instanceof Error ? error.message : "Unknown extension error.";
    sendResponse({ ok: false, error: text });
  });
  return true;
});
chrome.tabs.onRemoved.addListener(() => {
  clearBadgeIfNoMeetingTabs();
});
chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
  if (!changeInfo.url && changeInfo.status !== "complete")
    return;
  if (isMeetingUrl(tab.url))
    return;
  clearBadgeIfNoMeetingTabs();
});
