// src/shared/constants.ts
var DEFAULT_SETTINGS = {
  apiBaseUrl: "",
  apiToken: "",
  connectionToken: "",
  extensionAccessToken: "",
  extensionAccessTokenExpiresAt: "",
  linkedAccountEmail: "",
  connectedAt: "",
  defaultBotName: "Squaads Assistant",
  defaultDurationMinutes: 60
};
var REQUEST_TIMEOUT_MS = 1e4;
var HANDSHAKE_TIMEOUT_MS = 2000;
var FALLBACK_ALARM_PERIOD_MIN = 0.5;
var FALLBACK_ALARM_NAME = "squaads-poll-fallback";

// src/shared/storage.ts
async function getSettings() {
  const result = await chrome.storage.sync.get([
    "apiBaseUrl",
    "apiToken",
    "connectionToken",
    "extensionAccessToken",
    "extensionAccessTokenExpiresAt",
    "linkedAccountEmail",
    "connectedAt",
    "defaultBotName",
    "defaultDurationMinutes"
  ]);
  return {
    apiBaseUrl: result.apiBaseUrl || DEFAULT_SETTINGS.apiBaseUrl,
    apiToken: result.apiToken || DEFAULT_SETTINGS.apiToken,
    connectionToken: result.connectionToken || DEFAULT_SETTINGS.connectionToken,
    extensionAccessToken: result.extensionAccessToken || DEFAULT_SETTINGS.extensionAccessToken,
    extensionAccessTokenExpiresAt: result.extensionAccessTokenExpiresAt || DEFAULT_SETTINGS.extensionAccessTokenExpiresAt,
    linkedAccountEmail: result.linkedAccountEmail || DEFAULT_SETTINGS.linkedAccountEmail,
    connectedAt: result.connectedAt || DEFAULT_SETTINGS.connectedAt,
    defaultBotName: result.defaultBotName || DEFAULT_SETTINGS.defaultBotName,
    defaultDurationMinutes: result.defaultDurationMinutes || DEFAULT_SETTINGS.defaultDurationMinutes
  };
}
async function saveSettings(settings) {
  await chrome.storage.sync.set({
    apiBaseUrl: settings.apiBaseUrl.trim().replace(/\/$/, ""),
    apiToken: settings.apiToken.trim(),
    connectionToken: settings.connectionToken.trim(),
    extensionAccessToken: settings.extensionAccessToken.trim(),
    extensionAccessTokenExpiresAt: settings.extensionAccessTokenExpiresAt,
    linkedAccountEmail: settings.linkedAccountEmail.trim(),
    connectedAt: settings.connectedAt,
    defaultBotName: settings.defaultBotName.trim() || DEFAULT_SETTINGS.defaultBotName,
    defaultDurationMinutes: settings.defaultDurationMinutes || DEFAULT_SETTINGS.defaultDurationMinutes
  });
}

// src/shared/meeting-url.ts
function detectMeetingProvider(url) {
  const lower = url.toLowerCase();
  if (lower.includes("meet.google.com"))
    return "google-meet";
  if (lower.includes("teams.microsoft.com"))
    return "microsoft-teams";
  if (lower.includes("zoom.us") || lower.includes(".zoom.com"))
    return "zoom";
  return null;
}
function normalizeMeetingUrl(url, provider) {
  try {
    const parsed = new URL(url.trim());
    parsed.hash = "";
    if (provider === "google-meet") {
      const match = parsed.href.match(/https:\/\/meet\.google\.com\/[a-z]{3}-[a-z]{4}-[a-z]{3}/i);
      return match ? match[0].toLowerCase() : null;
    }
    parsed.protocol = "https:";
    parsed.hostname = parsed.hostname.toLowerCase();
    parsed.pathname = parsed.pathname.replace(/\/+$/, "");
    return parsed.toString();
  } catch {
    return null;
  }
}

// src/shared/origin.ts
function normalizeOrigin(input) {
  try {
    const parsed = new URL(input.trim());
    const protocol = parsed.protocol.toLowerCase();
    const hostname = parsed.hostname.toLowerCase();
    const port = parsed.port;
    const isDefaultPort = protocol === "https:" && port === "443" || protocol === "http:" && port === "80";
    const host = port && !isDefaultPort ? `${hostname}:${port}` : hostname;
    return `${protocol}//${host}`;
  } catch {
    return "";
  }
}
function getConnectableSiteContext(url) {
  if (!url) {
    return {
      origin: "",
      eligible: false,
      reason: "Open the Squaads dashboard tab where you generated the token, then try again."
    };
  }
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return {
      origin: "",
      eligible: false,
      reason: "This tab cannot be used for connection. Open the Squaads dashboard first."
    };
  }
  if (!["http:", "https:"].includes(parsed.protocol)) {
    return {
      origin: "",
      eligible: false,
      reason: "Only a Squaads web tab can finish connection. Browser internal pages are not supported."
    };
  }
  const provider = detectMeetingProvider(url);
  if (provider && normalizeMeetingUrl(url, provider)) {
    return {
      origin: "",
      eligible: false,
      reason: "You are on a meeting tab. Return to the Squaads dashboard tab where you generated the token."
    };
  }
  if (parsed.hostname === "chromewebstore.google.com" || parsed.hostname === "chrome.google.com" && parsed.pathname.startsWith("/webstore")) {
    return {
      origin: "",
      eligible: false,
      reason: "Return to the Squaads dashboard tab after visiting the Chrome Web Store."
    };
  }
  const origin = normalizeOrigin(parsed.toString());
  return {
    origin,
    eligible: Boolean(origin),
    reason: origin ? `Current site ready: ${origin}` : "Open the Squaads dashboard tab before connecting."
  };
}

// src/shared/logger.ts
var PREFIX = "[squaads-ext]";
function logInfo(message, meta) {
  if (meta !== undefined) {
    console.log(`${PREFIX} ${message}`, meta);
    return;
  }
  console.log(`${PREFIX} ${message}`);
}
function logError(message, meta) {
  if (meta !== undefined) {
    console.error(`${PREFIX} ${message}`, meta);
    return;
  }
  console.error(`${PREFIX} ${message}`);
}

// src/background/api-client.ts
function isExpired(isoTimestamp) {
  if (!isoTimestamp)
    return false;
  const parsed = Date.parse(isoTimestamp);
  if (Number.isNaN(parsed))
    return false;
  return parsed <= Date.now();
}
function mapApiError(status, text) {
  if (status === 401) {
    if (/expired link token/i.test(text))
      return "This connection token expired. Go back to the Squaads dashboard and generate a new one.";
    if (/expired extension access token/i.test(text))
      return "Your secure extension session expired. Reconnect it from the Squaads dashboard.";
    if (/invalid or expired extension access token/i.test(text))
      return "Your secure extension session expired. Reconnect it from the Squaads dashboard.";
    if (/invalid or expired link token/i.test(text))
      return "This connection token is invalid or expired. Generate a new one from the dashboard.";
    return "Unauthorized. Verify extension connection or legacy API token.";
  }
  if (status === 403) {
    if (/origin mismatch/i.test(text))
      return "Wrong site for this token. Open the same Squaads dashboard tab where you generated it and try again.";
    return "Forbidden by server.";
  }
  if (status === 404)
    return "Endpoint not found. Verify API base URL.";
  if (status >= 500)
    return "Server error. Please check backend logs.";
  return `API ${status}: ${text}`;
}
async function resolveTransport(path) {
  let settings = await getSettings();
  const apiBaseUrl = settings.apiBaseUrl;
  if (!apiBaseUrl) {
    throw new Error("Extension not configured. Open Configuration and connect it first.");
  }
  if (settings.extensionAccessToken) {
    if (isExpired(settings.extensionAccessTokenExpiresAt)) {
      settings = {
        ...settings,
        connectionToken: "",
        extensionAccessToken: "",
        extensionAccessTokenExpiresAt: "",
        linkedAccountEmail: "",
        connectedAt: ""
      };
      await saveSettings(settings);
      if (!settings.apiToken) {
        throw new Error("Secure extension session expired. Reconnect it from the Squaads dashboard.");
      }
    }
  }
  if (settings.extensionAccessToken) {
    return {
      apiBaseUrl,
      token: settings.extensionAccessToken,
      authMode: "linked-session",
      path: path.replace("/api/", "/api/v1/extension/")
    };
  }
  if (settings.apiToken) {
    return {
      apiBaseUrl,
      token: settings.apiToken,
      authMode: "legacy-token",
      path
    };
  }
  throw new Error("Extension not configured. Connect it with a secure token or add a legacy API token.");
}
async function apiFetch(path, init = {}) {
  const transport = await resolveTransport(path);
  const controller = new AbortController;
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(`${transport.apiBaseUrl}${transport.path}`, {
      ...init,
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${transport.token}`,
        ...init.headers || {}
      }
    });
    if (!response.ok) {
      const text = await response.text().catch(() => response.statusText);
      throw new Error(mapApiError(response.status, text));
    }
    return await response.json();
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") {
      throw new Error("Server timeout after 10s. Verify backend is reachable.");
    }
    logError("apiFetch failed", error);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}
async function connectExtension(apiBaseUrl, linkToken) {
  const controller = new AbortController;
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(`${apiBaseUrl.replace(/\/$/, "")}/api/v1/extension/connect`, {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ linkToken })
    });
    if (!response.ok) {
      const text = await response.text().catch(() => response.statusText);
      throw new Error(mapApiError(response.status, text));
    }
    return await response.json();
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") {
      throw new Error("Server timeout after 10s. Verify backend is reachable.");
    }
    logError("connectExtension failed", error);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}
async function checkStatus(meetingUrl, provider) {
  logInfo("checkStatus", { provider, meetingUrl });
  return apiFetch(`/api/meetings/status?url=${encodeURIComponent(meetingUrl)}&provider=${encodeURIComponent(provider)}`);
}
async function inviteBot(meetingUrl, provider, botName, duration) {
  logInfo("inviteBot", { provider, meetingUrl });
  const payload = await apiFetch("/api/bot/start", {
    method: "POST",
    body: JSON.stringify({
      meetingUrl,
      provider,
      botName,
      duration
    })
  });
  const first = payload.results[0];
  if (!first)
    throw new Error("Invalid start response.");
  if (!first.queued || !first.meetingId) {
    throw new Error(first.error || "Bot was not queued.");
  }
  return {
    meetingId: first.meetingId,
    queued: first.queued,
    provider: first.provider,
    normalizedUrl: first.url
  };
}
async function pollMeeting(meetingId) {
  return apiFetch(`/api/meetings/${meetingId}`);
}

// src/shared/status-sync.ts
var TRANSITION_INTERVAL_MS = 2000;
var STABLE_INTERVAL_MS = 5000;
function intervalFor(status) {
  switch (status) {
    case "pending":
    case "joining":
    case "waiting_admission":
      return TRANSITION_INTERVAL_MS;
    case "recording":
    case "transcribing":
    case "summarizing":
      return STABLE_INTERVAL_MS;
    default:
      return STABLE_INTERVAL_MS;
  }
}
var TERMINAL_STATUSES = [
  "completed",
  "admission_timeout",
  "rejected",
  "error"
];
function isTerminal(status) {
  return TERMINAL_STATUSES.includes(status);
}
function initialState() {
  return { meetings: {} };
}
function removeMeeting(state, meetingId) {
  const meetings = { ...state.meetings };
  delete meetings[meetingId];
  return { meetings };
}
function setMeeting(state, meetingId, loop) {
  return { meetings: { ...state.meetings, [meetingId]: loop } };
}
function handleSubscribe(state, event) {
  const existing = state.meetings[event.meetingId];
  if (!existing) {
    const interval = intervalFor("pending");
    const loop2 = {
      portIds: [event.portId],
      inFlight: false,
      lastStatus: null,
      interval
    };
    return {
      state: setMeeting(state, event.meetingId, loop2),
      effects: [
        { type: "startLoop", meetingId: event.meetingId, interval },
        { type: "fetchSnapshot", meetingId: event.meetingId, portId: event.portId }
      ]
    };
  }
  const loop = {
    ...existing,
    portIds: [...existing.portIds, event.portId]
  };
  return {
    state: setMeeting(state, event.meetingId, loop),
    effects: [
      { type: "fetchSnapshot", meetingId: event.meetingId, portId: event.portId }
    ]
  };
}
function handlePollTick(state, event) {
  const meeting = state.meetings[event.meetingId];
  if (!meeting || meeting.inFlight) {
    return { state, effects: [] };
  }
  const loop = { ...meeting, inFlight: true };
  return {
    state: setMeeting(state, event.meetingId, loop),
    effects: [{ type: "fetchMeeting", meetingId: event.meetingId }]
  };
}
function handlePollResponse(state, event) {
  const meeting = state.meetings[event.meetingId];
  if (!meeting || !meeting.inFlight) {
    return { state, effects: [] };
  }
  if (isTerminal(event.status)) {
    return {
      state: removeMeeting(state, event.meetingId),
      effects: [
        { type: "broadcast", meetingId: event.meetingId, status: event.status },
        { type: "stopLoop", meetingId: event.meetingId },
        { type: "disconnectPorts", meetingId: event.meetingId }
      ]
    };
  }
  const loop = {
    ...meeting,
    inFlight: false,
    lastStatus: event.status,
    interval: intervalFor(event.status)
  };
  return {
    state: setMeeting(state, event.meetingId, loop),
    effects: [{ type: "broadcast", meetingId: event.meetingId, status: event.status }]
  };
}
function handleDisconnect(state, event) {
  const meeting = state.meetings[event.meetingId];
  if (!meeting) {
    return { state, effects: [] };
  }
  const remainingPorts = meeting.portIds.filter((id) => id !== event.portId);
  if (remainingPorts.length === 0) {
    return {
      state: removeMeeting(state, event.meetingId),
      effects: [{ type: "stopLoop", meetingId: event.meetingId }]
    };
  }
  const loop = { ...meeting, portIds: remainingPorts };
  return {
    state: setMeeting(state, event.meetingId, loop),
    effects: []
  };
}
function handlePollError(state, event) {
  const meeting = state.meetings[event.meetingId];
  if (!meeting || !meeting.inFlight) {
    return { state, effects: [] };
  }
  const loop = { ...meeting, inFlight: false };
  return {
    state: setMeeting(state, event.meetingId, loop),
    effects: []
  };
}
function handleHandshakeTimeout(state, event) {
  return {
    state,
    effects: [{ type: "disconnectPort", portId: event.portId }]
  };
}
function transition(state, event) {
  switch (event.type) {
    case "SUBSCRIBE":
      return handleSubscribe(state, event);
    case "POLL_TICK":
      return handlePollTick(state, event);
    case "POLL_RESPONSE":
      return handlePollResponse(state, event);
    case "POLL_ERROR":
      return handlePollError(state, event);
    case "DISCONNECT":
      return handleDisconnect(state, event);
    case "HANDSHAKE_TIMEOUT":
      return handleHandshakeTimeout(state, event);
  }
}

// src/background/service-worker.ts
function isMeetingUrl(url) {
  if (!url)
    return false;
  const provider = detectMeetingProvider(url);
  if (!provider)
    return false;
  return Boolean(normalizeMeetingUrl(url, provider));
}
async function clearBadgeIfNoMeetingTabs() {
  const tabs = await chrome.tabs.query({});
  const hasMeetingTab = tabs.some((tab) => isMeetingUrl(tab.url));
  if (!hasMeetingTab) {
    setBadge("clear");
  }
}
function setBadge(state) {
  if (state === "recording") {
    chrome.action.setBadgeText({ text: "REC" });
    chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
    return;
  }
  if (state === "error") {
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
    return;
  }
  chrome.action.setBadgeText({ text: "" });
}
async function handleMessage(message) {
  logInfo("runtime message", { type: message.type });
  switch (message.type) {
    case "GET_SETTINGS":
      return { ok: true, data: await getSettings() };
    case "SAVE_SETTINGS": {
      const merged = {
        ...DEFAULT_SETTINGS,
        ...message.settings
      };
      await saveSettings(merged);
      return { ok: true };
    }
    case "CONNECT_EXTENSION": {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const manualBaseUrl = message.apiBaseUrl?.trim();
      const connectContext = getConnectableSiteContext(tab?.url);
      const apiBaseUrl = manualBaseUrl || connectContext.origin;
      if (!manualBaseUrl && !connectContext.eligible) {
        return { ok: false, error: connectContext.reason };
      }
      if (!apiBaseUrl) {
        return { ok: false, error: "Open the Squaads dashboard tab before connecting the extension." };
      }
      const connection = await connectExtension(apiBaseUrl, message.linkToken);
      const current = await getSettings();
      await saveSettings({
        ...current,
        apiBaseUrl: connection.apiBaseUrl,
        connectionToken: "",
        extensionAccessToken: connection.extensionAccessToken,
        extensionAccessTokenExpiresAt: connection.expiresAt,
        linkedAccountEmail: connection.linkedAccountEmail,
        connectedAt: new Date().toISOString()
      });
      return { ok: true, data: connection };
    }
    case "CHECK_STATUS":
      return { ok: true, data: await checkStatus(message.meetingUrl, message.provider) };
    case "INVITE_BOT": {
      const settings = await getSettings();
      const botName = message.botName || settings.defaultBotName || DEFAULT_SETTINGS.defaultBotName;
      const duration = message.duration || settings.defaultDurationMinutes || DEFAULT_SETTINGS.defaultDurationMinutes;
      return {
        ok: true,
        data: await inviteBot(message.meetingUrl, message.provider, botName, duration)
      };
    }
    case "POLL_MEETING":
      return { ok: true, data: await pollMeeting(message.meetingId) };
    case "SET_BADGE":
      setBadge(message.state);
      return { ok: true };
    default:
      return { ok: false, error: "Unknown runtime message." };
  }
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message).then((res) => sendResponse(res)).catch((error) => {
    logError("runtime message failed", error);
    const text = error instanceof Error ? error.message : "Unknown extension error.";
    sendResponse({ ok: false, error: text });
  });
  return true;
});
var STATUS_PORT_NAME = "squaads-status";
var syncState = initialState();
var ports = new Map;
var portMeeting = new Map;
var loopTimers = new Map;
var handshakeTimers = new Map;
var portSeq = 0;
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== STATUS_PORT_NAME)
    return;
  const portId = `port-${++portSeq}`;
  ports.set(portId, port);
  const handshakeTimer = setTimeout(() => {
    handshakeTimers.delete(portId);
    const result = transition(syncState, { type: "HANDSHAKE_TIMEOUT", portId });
    syncState = result.state;
    executeEffects(result.effects);
  }, HANDSHAKE_TIMEOUT_MS);
  handshakeTimers.set(portId, handshakeTimer);
  port.onMessage.addListener((msg) => {
    if (msg.type === "HELLO") {
      const ht2 = handshakeTimers.get(portId);
      if (ht2) {
        clearTimeout(ht2);
        handshakeTimers.delete(portId);
      }
      return;
    }
    if (msg.type !== "SUBSCRIBE")
      return;
    const ht = handshakeTimers.get(portId);
    if (ht) {
      clearTimeout(ht);
      handshakeTimers.delete(portId);
    }
    portMeeting.set(portId, msg.meetingId);
    logInfo("SUBSCRIBE", { meetingId: msg.meetingId, portId });
    const result = transition(syncState, { type: "SUBSCRIBE", meetingId: msg.meetingId, portId });
    syncState = result.state;
    executeEffects(result.effects);
  });
  port.onDisconnect.addListener(() => {
    const ht = handshakeTimers.get(portId);
    if (ht) {
      clearTimeout(ht);
      handshakeTimers.delete(portId);
    }
    if (!ports.has(portId))
      return;
    ports.delete(portId);
    const meetingId = portMeeting.get(portId);
    portMeeting.delete(portId);
    if (meetingId) {
      const result = transition(syncState, { type: "DISCONNECT", meetingId, portId });
      syncState = result.state;
      executeEffects(result.effects);
    }
  });
});
function executeEffects(effects) {
  for (const effect of effects) {
    try {
      executeEffect(effect);
    } catch (error) {
      logError("effect failed", { effect, error });
    }
  }
}
function executeEffect(effect) {
  switch (effect.type) {
    case "startLoop":
      logInfo("startLoop", { meetingId: effect.meetingId, interval: effect.interval });
      break;
    case "stopLoop":
      stopLoop(effect.meetingId);
      break;
    case "fetchSnapshot":
      fetchSnapshot(effect.meetingId, effect.portId);
      break;
    case "fetchMeeting":
      fetchAndProcess(effect.meetingId);
      break;
    case "broadcast":
      broadcast(effect.meetingId, effect.status);
      break;
    case "disconnectPorts":
      disconnectPorts(effect.meetingId);
      break;
    case "disconnectPort":
      disconnectPort(effect.portId);
      break;
  }
}
function stopLoop(meetingId) {
  const timer = loopTimers.get(meetingId);
  if (timer) {
    clearTimeout(timer);
    loopTimers.delete(meetingId);
  }
}
function scheduleNextTick(meetingId, interval) {
  stopLoop(meetingId);
  const timer = setTimeout(() => {
    const result = transition(syncState, { type: "POLL_TICK", meetingId });
    syncState = result.state;
    executeEffects(result.effects);
  }, interval);
  loopTimers.set(meetingId, timer);
}
async function fetchSnapshot(meetingId, portId) {
  const meeting = syncState.meetings[meetingId];
  if (meeting?.lastStatus) {
    sendToPort(portId, meetingId, meeting.lastStatus);
    return;
  }
  if (meeting?.inFlight) {
    return;
  }
  const result = transition(syncState, { type: "POLL_TICK", meetingId });
  syncState = result.state;
  executeEffects(result.effects);
}
async function fetchAndProcess(meetingId) {
  try {
    const record = await pollMeeting(meetingId);
    const result = transition(syncState, {
      type: "POLL_RESPONSE",
      meetingId,
      status: record.status
    });
    syncState = result.state;
    executeEffects(result.effects);
  } catch (error) {
    logError("poll failed", error);
    const result = transition(syncState, { type: "POLL_ERROR", meetingId });
    syncState = result.state;
    executeEffects(result.effects);
  }
  const loop = syncState.meetings[meetingId];
  if (loop) {
    scheduleNextTick(meetingId, loop.interval);
  }
}
function broadcast(meetingId, status) {
  for (const [pid, mid] of portMeeting) {
    if (mid === meetingId) {
      sendToPort(pid, meetingId, status);
    }
  }
}
function sendToPort(portId, meetingId, status) {
  const port = ports.get(portId);
  if (!port)
    return;
  try {
    port.postMessage({ type: "MEETING_UPDATE", meetingId, status });
  } catch (error) {
    logError("sendToPort failed", { portId, error });
    ports.delete(portId);
    portMeeting.delete(portId);
  }
}
function disconnectPorts(meetingId) {
  const toDisconnect = [];
  for (const [pid, mid] of portMeeting) {
    if (mid === meetingId)
      toDisconnect.push(pid);
  }
  for (const pid of toDisconnect) {
    const port = ports.get(pid);
    ports.delete(pid);
    portMeeting.delete(pid);
    port?.disconnect();
  }
}
function disconnectPort(portId) {
  const port = ports.get(portId);
  ports.delete(portId);
  portMeeting.delete(portId);
  port?.disconnect();
}
if (typeof chrome.alarms !== "undefined") {
  chrome.alarms.create(FALLBACK_ALARM_NAME, { periodInMinutes: FALLBACK_ALARM_PERIOD_MIN });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name !== FALLBACK_ALARM_NAME)
      return;
    if (ports.size > 0)
      return;
    for (const meetingId of Object.keys(syncState.meetings)) {
      const meeting = syncState.meetings[meetingId];
      if (!meeting.inFlight) {
        fetchAndProcess(meetingId);
      }
    }
  });
}
chrome.tabs.onRemoved.addListener(() => {
  clearBadgeIfNoMeetingTabs();
});
chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
  if (!changeInfo.url && changeInfo.status !== "complete")
    return;
  if (isMeetingUrl(tab.url))
    return;
  clearBadgeIfNoMeetingTabs();
});
