// src/shared/meeting-url.ts
function normalizeMeetingUrl(url, provider) {
  try {
    const parsed = new URL(url.trim());
    parsed.hash = "";
    if (provider === "google-meet") {
      const match = parsed.href.match(/https:\/\/meet\.google\.com\/[a-z]{3}-[a-z]{4}-[a-z]{3}/i);
      return match ? match[0].toLowerCase() : null;
    }
    parsed.protocol = "https:";
    parsed.hostname = parsed.hostname.toLowerCase();
    parsed.pathname = parsed.pathname.replace(/\/+$/, "");
    return parsed.toString();
  } catch {
    return null;
  }
}

// src/content/adapters/meet.ts
var googleMeetAdapter = {
  provider: "google-meet",
  canHandle(url) {
    return url.includes("meet.google.com");
  },
  getMeetingUrl(url) {
    return normalizeMeetingUrl(url, "google-meet");
  },
  isInsideActiveMeeting() {
    const title = document.title.toLowerCase();
    const text = (document.body?.innerText || "").toLowerCase();
    if (title.includes("ready to join") || title.includes("join now"))
      return false;
    if (text.includes("join now") || text.includes("ask to join"))
      return false;
    return true;
  }
};

// src/content/adapters/teams.ts
var microsoftTeamsAdapter = {
  provider: "microsoft-teams",
  canHandle(url) {
    return url.includes("teams.microsoft.com");
  },
  getMeetingUrl(url) {
    return normalizeMeetingUrl(url, "microsoft-teams");
  },
  isInsideActiveMeeting() {
    const bodyText = (document.body?.innerText || "").toLowerCase();
    if (bodyText.includes("join now") || bodyText.includes("unirse ahora"))
      return false;
    if (bodyText.includes("waiting in the lobby") || bodyText.includes("esperando en el vestibulo"))
      return true;
    return bodyText.includes("meeting") || bodyText.includes("reunion");
  }
};

// src/content/adapters/zoom.ts
var zoomWebAdapter = {
  provider: "zoom",
  canHandle(url) {
    return url.includes("zoom.us") || url.includes(".zoom.com");
  },
  getMeetingUrl(url) {
    return normalizeMeetingUrl(url, "zoom");
  },
  isInsideActiveMeeting() {
    const href = window.location.href.toLowerCase();
    const bodyText = (document.body?.innerText || "").toLowerCase();
    if (bodyText.includes("join meeting") || bodyText.includes("unirse a la reunion"))
      return false;
    return href.includes("/wc/") || bodyText.includes("in meeting") || bodyText.includes("en reunion");
  }
};

// src/content/adapters/index.ts
var ADAPTERS = [googleMeetAdapter, microsoftTeamsAdapter, zoomWebAdapter];
function pickAdapter(url) {
  return ADAPTERS.find((a) => a.canHandle(url)) || null;
}

// src/shared/badge-policy.ts
var BADGE_ERROR_STATUSES = ["error", "transcription_error"];
function resolveBadgeState(status) {
  if (status === "recording")
    return "recording";
  if (status !== null && BADGE_ERROR_STATUSES.includes(status))
    return "error";
  return "clear";
}

// src/shared/constants.ts
var ACTIVE_STATUSES = [
  "pending",
  "joining",
  "waiting_admission",
  "recording",
  "transcribing",
  "summarizing"
];
var TRACKABLE_STATUSES = [...ACTIVE_STATUSES, "transcription_error"];
var RETRYABLE_TERMINAL_STATUSES = ["admission_timeout", "rejected", "error"];
var STATUS_LABELS = {
  pending: "Queued",
  joining: "Joining",
  waiting_admission: "Waiting admission",
  recording: "Recording",
  transcribing: "Transcribing",
  summarizing: "Summarizing",
  completed: "Completed",
  admission_timeout: "Admission timeout",
  rejected: "Rejected",
  error: "Error",
  transcription_error: "Transcription error"
};
var STATUS_COLORS = {
  pending: "#f59e0b",
  joining: "#3b82f6",
  waiting_admission: "#f59e0b",
  recording: "#ef4444",
  transcribing: "#8b5cf6",
  summarizing: "#8b5cf6",
  completed: "#10b981",
  admission_timeout: "#ef4444",
  rejected: "#ef4444",
  error: "#ef4444",
  transcription_error: "#ef4444"
};

// src/shared/status-sync.ts
function diff(prev, next) {
  if (prev.type !== next.type) {
    return { attribute: "full" };
  }
  if (prev.type === "active" && next.type === "active") {
    if (prev.status !== next.status) {
      return { attribute: "status", value: next.status };
    }
  }
  return { attribute: "none" };
}

// src/shared/storage.ts
var WIDGET_POSITION_KEY = "widgetPosition";
async function getWidgetPosition() {
  const result = await chrome.storage.local.get(WIDGET_POSITION_KEY);
  const stored = result[WIDGET_POSITION_KEY];
  if (!stored || typeof stored.x !== "number" || typeof stored.y !== "number") {
    return null;
  }
  return stored;
}
async function saveWidgetPosition(position) {
  await chrome.storage.local.set({
    [WIDGET_POSITION_KEY]: position
  });
}

// src/content/widget.ts
function send(message) {
  return chrome.runtime.sendMessage(message);
}
var STATUS_PORT_NAME = "squaads-status";
function reconnectBackoff(attempts) {
  if (attempts <= 0)
    return 0;
  return Math.min(1000 * 2 ** (attempts - 1), 4000);
}

class MeetingWidget {
  host;
  meetingUrl;
  provider;
  state = { type: "checking" };
  statusRequestInFlight = false;
  collapsed = false;
  destroyed = false;
  dragging = false;
  hovered = false;
  idleTimer = null;
  position = null;
  dragOffsetX = 0;
  dragOffsetY = 0;
  boundPointerMove;
  boundPointerUp;
  port = null;
  subscribedMeetingId = null;
  expectedDisconnect = false;
  reconnectAttempts = 0;
  reconnectTimer = null;
  constructor(meetingUrl, provider) {
    this.meetingUrl = meetingUrl;
    this.provider = provider;
    this.host = document.createElement("div");
    this.host.id = "squaads-widget-root";
    this.host.style.cssText = "position:fixed;bottom:20px;right:20px;z-index:2147483647;font-family:system-ui,sans-serif;transition:opacity .18s ease, transform .18s ease;opacity:.72;";
    document.body.appendChild(this.host);
    this.boundPointerMove = (event) => this.onPointerMove(event);
    this.boundPointerUp = () => this.onPointerUp();
    this.openPort();
    this.host.addEventListener("mouseenter", () => {
      this.hovered = true;
      this.syncVisualState();
    });
    this.host.addEventListener("mouseleave", () => {
      this.hovered = false;
      this.scheduleIdleVisuals();
    });
    this.restorePosition();
    this.scheduleIdleVisuals();
    this.mount();
  }
  openPort() {
    this.port = chrome.runtime.connect({ name: STATUS_PORT_NAME });
    this.port.onMessage.addListener((msg) => {
      if (msg.type !== "MEETING_UPDATE")
        return;
      if (msg.meetingId !== this.subscribedMeetingId)
        return;
      this.applyPortUpdate(msg.status);
    });
    this.port.postMessage({ type: "HELLO" });
    this.port.onDisconnect.addListener(() => {
      this.port = null;
      if (this.expectedDisconnect)
        return;
      this.subscribedMeetingId = null;
      this.reopenPort();
    });
  }
  reopenPort() {
    if (this.isInactive())
      return;
    const delay = reconnectBackoff(this.reconnectAttempts);
    this.reconnectAttempts += 1;
    this.reconnectTimer = setTimeout(() => {
      if (this.isInactive())
        return;
      this.openPort();
      if (this.state.type === "active" && this.state.meetingId) {
        this.subscribe(this.state.meetingId);
      }
    }, delay);
  }
  subscribe(meetingId) {
    if (this.isInactive())
      return;
    if (this.subscribedMeetingId === meetingId && this.port)
      return;
    this.subscribedMeetingId = meetingId;
    this.reconnectAttempts = 0;
    this.port?.postMessage({ type: "SUBSCRIBE", meetingId, provider: this.provider });
  }
  async bootstrap() {
    await this.checkStatus();
  }
  sync() {}
  destroy() {
    if (this.destroyed)
      return;
    this.destroyed = true;
    this.expectedDisconnect = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.port?.disconnect();
    this.port = null;
    this.clearIdleTimer();
    window.removeEventListener("pointermove", this.boundPointerMove);
    window.removeEventListener("pointerup", this.boundPointerUp);
    this.host.remove();
    send({ type: "SET_BADGE", state: "clear" });
  }
  restore() {
    if (this.isInactive())
      return;
    this.expand();
    this.bringToFront();
  }
  getViewState() {
    return { collapsed: this.collapsed };
  }
  setState(next) {
    if (this.isInactive())
      return;
    const prevRender = this.toRenderState(this.state);
    const nextRender = this.toRenderState(next);
    this.state = next;
    this.syncBadge();
    const patch = diff(prevRender, nextRender);
    switch (patch.attribute) {
      case "none":
        return;
      case "full":
        this.mount();
        return;
      case "status":
        this.patchStatus(patch.value);
    }
  }
  toRenderState(state) {
    if (state.type === "active") {
      return { type: "active", status: state.status };
    }
    return { type: state.type, status: null };
  }
  patchStatus(status) {
    if (this.isInactive())
      return;
    const color = STATUS_COLORS[status];
    const label = STATUS_LABELS[status];
    this.host.querySelectorAll("[data-squaads-indicator]").forEach((el) => {
      el.style.background = color;
      el.style.boxShadow = `0 0 16px ${color}`;
    });
    this.host.querySelectorAll("[data-squaads-message]").forEach((el) => {
      el.textContent = label;
    });
    const action = this.host.querySelector("#squaads-primary-btn");
    if (action) {
      action.textContent = label;
      action.style.background = color;
    }
  }
  isInactive() {
    return this.destroyed;
  }
  applyPortUpdate(status) {
    if (this.isInactive())
      return;
    if (RETRYABLE_TERMINAL_STATUSES.includes(status)) {
      this.setState({ type: "error", message: STATUS_LABELS[status] });
      return;
    }
    this.setState({
      type: "active",
      meetingId: this.subscribedMeetingId ?? "",
      status
    });
  }
  syncBadge() {
    if (this.state.type === "active") {
      send({ type: "SET_BADGE", state: resolveBadgeState(this.state.status) });
      return;
    }
    if (this.state.type === "error") {
      send({ type: "SET_BADGE", state: "error" });
      return;
    }
    send({ type: "SET_BADGE", state: "clear" });
  }
  scheduleIdleVisuals() {
    this.clearIdleTimer();
    this.idleTimer = setTimeout(() => {
      this.syncVisualState();
    }, 900);
  }
  clearIdleTimer() {
    if (!this.idleTimer)
      return;
    clearTimeout(this.idleTimer);
    this.idleTimer = null;
  }
  syncVisualState() {
    if (this.isInactive())
      return;
    const active = this.dragging || this.hovered;
    this.host.style.opacity = active ? "1" : "0.72";
    this.host.style.transform = active ? "translateY(0)" : "translateY(2px)";
  }
  bringToFront() {
    this.hovered = true;
    this.syncVisualState();
    this.scheduleIdleVisuals();
  }
  async restorePosition() {
    const saved = await getWidgetPosition();
    if (!saved || this.isInactive())
      return;
    this.position = this.clampPosition(saved);
    this.applyPosition();
  }
  clampPosition(position) {
    const margin = 12;
    const width = this.host.offsetWidth || (this.collapsed ? 260 : 360);
    const height = this.host.offsetHeight || 56;
    const maxX = Math.max(margin, window.innerWidth - width - margin);
    const maxY = Math.max(margin, window.innerHeight - height - margin);
    return {
      x: Math.min(Math.max(position.x, margin), maxX),
      y: Math.min(Math.max(position.y, margin), maxY)
    };
  }
  applyPosition() {
    if (!this.position) {
      this.host.style.left = "";
      this.host.style.top = "";
      this.host.style.right = "20px";
      this.host.style.bottom = "20px";
      return;
    }
    this.host.style.left = `${this.position.x}px`;
    this.host.style.top = `${this.position.y}px`;
    this.host.style.right = "auto";
    this.host.style.bottom = "auto";
  }
  beginDrag(event) {
    if (event.button !== 0)
      return;
    const target = event.target;
    const isCollapsedButton = Boolean(target?.closest("#squaads-expand-btn"));
    if (target?.closest("button") && !target.closest("#squaads-drag-handle") && !isCollapsedButton) {
      return;
    }
    const rect = this.host.getBoundingClientRect();
    this.position = { x: rect.left, y: rect.top };
    this.applyPosition();
    this.dragging = true;
    this.dragOffsetX = event.clientX - rect.left;
    this.dragOffsetY = event.clientY - rect.top;
    this.host.style.cursor = "grabbing";
    this.host.setPointerCapture?.(event.pointerId);
    window.addEventListener("pointermove", this.boundPointerMove);
    window.addEventListener("pointerup", this.boundPointerUp);
    this.syncVisualState();
  }
  onPointerMove(event) {
    if (!this.dragging)
      return;
    const next = this.clampPosition({
      x: event.clientX - this.dragOffsetX,
      y: event.clientY - this.dragOffsetY
    });
    this.position = next;
    this.applyPosition();
  }
  onPointerUp() {
    if (!this.dragging)
      return;
    this.dragging = false;
    this.host.style.cursor = "default";
    window.removeEventListener("pointermove", this.boundPointerMove);
    window.removeEventListener("pointerup", this.boundPointerUp);
    if (this.position) {
      saveWidgetPosition(this.position);
    }
    this.scheduleIdleVisuals();
  }
  mount() {
    const wrap = "display:flex;gap:10px;align-items:center;padding:12px 13px;border-radius:22px;min-width:280px;max-width:390px;position:relative;overflow:hidden;backdrop-filter:blur(18px);";
    const card = "background:linear-gradient(145deg, rgba(8,15,29,.94), rgba(12,25,44,.88));color:#f8fafc;border:1px solid rgba(148,163,184,.18);box-shadow:0 24px 60px rgba(2,8,23,.45), inset 0 1px 0 rgba(255,255,255,.05)";
    const content = "display:flex;flex-direction:column;gap:4px;min-width:0;flex:1;position:relative;z-index:1;";
    const statusLabel = "font-size:12px;line-height:1.35;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600;";
    const metaLabel = "opacity:.72;text-transform:uppercase;font-size:10px;letter-spacing:.14em;color:#8da2be;";
    const button = "border:1px solid transparent;border-radius:999px;padding:9px 13px;min-width:120px;cursor:pointer;font-weight:800;font-size:12px;letter-spacing:.01em;position:relative;z-index:1;box-shadow:0 12px 28px rgba(14,165,233,.22);";
    const dismissButton = "border:1px solid rgba(148,163,184,.12);border-radius:999px;width:24px;height:24px;background:rgba(15,23,42,.68);color:#d1d5db;cursor:pointer;font-weight:700;position:relative;z-index:1";
    const providerLabel = this.provider.replace("-", " ");
    const indicator = this.state.type === "active" ? STATUS_COLORS[this.state.status] : "#6b7280";
    let message = "Checking bot status...";
    let actionLabel = "Checking...";
    let actionDisabled = true;
    let actionStyle = "background:rgba(51,65,85,.78);color:#d1d5db;box-shadow:none;";
    let actionHandler = null;
    if (this.state.type === "not_configured") {
      message = "Configure API URL/token in extension popup.";
      actionLabel = "Configure";
    }
    if (this.state.type === "idle") {
      message = "Bot not invited yet.";
      actionLabel = "Invite Bot";
      actionDisabled = false;
      actionStyle = "background:linear-gradient(135deg,#67e8f9,#38bdf8 45%,#2563eb);color:#03111d;";
      actionHandler = () => void this.invite();
    }
    if (this.state.type === "inviting") {
      message = STATUS_LABELS.pending;
      actionLabel = "Inviting...";
      actionStyle = "background:linear-gradient(135deg,#60a5fa,#2563eb);color:#e0f2fe;";
    }
    if (this.state.type === "error") {
      message = this.state.message;
      actionLabel = "Retry";
      actionDisabled = false;
      actionStyle = "background:linear-gradient(135deg,#fb7185,#be123c);color:#fff1f2;";
      actionHandler = () => void this.invite();
    }
    if (this.state.type === "active") {
      message = STATUS_LABELS[this.state.status];
      actionLabel = STATUS_LABELS[this.state.status];
      actionStyle = `background:${STATUS_COLORS[this.state.status]};color:#f9fafb;box-shadow:none;`;
    }
    if (this.collapsed) {
      this.host.innerHTML = `
        <button id="squaads-expand-btn" style="display:flex;gap:10px;align-items:center;padding:11px 14px;border-radius:999px;border:1px solid rgba(148,163,184,.18);background:linear-gradient(145deg, rgba(8,15,29,.94), rgba(12,25,44,.88));color:#f8fafc;box-shadow:0 24px 60px rgba(2,8,23,.45);cursor:pointer;max-width:280px;backdrop-filter:blur(18px);">
          <span data-squaads-indicator style="width:10px;height:10px;border-radius:999px;background:${indicator};display:inline-block;flex:0 0 auto;box-shadow:0 0 16px ${indicator};"></span>
          <span data-squaads-message style="font-size:12px;line-height:1.35;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:700;">${message}</span>
        </button>
      `;
      const expandButton = this.host.querySelector("#squaads-expand-btn");
      expandButton?.addEventListener("click", () => this.expand());
      expandButton?.addEventListener("pointerdown", (event) => this.beginDrag(event));
      this.applyPosition();
      this.syncVisualState();
      return;
    }
    this.host.innerHTML = `
      <div style="${wrap}${card}">
        <div style="position:absolute;inset:0;background:radial-gradient(circle at top left, rgba(103,232,249,.10), transparent 34%),radial-gradient(circle at bottom right, rgba(99,102,241,.12), transparent 30%);pointer-events:none;"></div>
        <button id="squaads-drag-handle" style="border:0;background:transparent;color:#94a3b8;cursor:grab;padding:0 2px;font-size:14px;line-height:1;position:relative;z-index:1">⋮⋮</button>
        <span data-squaads-indicator style="width:10px;height:10px;border-radius:999px;background:${indicator};display:inline-block;flex:0 0 auto;box-shadow:0 0 18px ${indicator};position:relative;z-index:1"></span>
        <div style="${content}">
          <span style="${metaLabel}">${providerLabel}</span>
          <span data-squaads-message style="${statusLabel}">${message}</span>
        </div>
        <button id="squaads-primary-btn" style="${button}${actionStyle}" ${actionDisabled ? "disabled" : ""}>${actionLabel}</button>
        <button id="squaads-dismiss-btn" style="${dismissButton}">x</button>
      </div>
    `;
    const primaryButton = this.host.querySelector("#squaads-primary-btn");
    const dismiss = this.host.querySelector("#squaads-dismiss-btn");
    const dragHandle = this.host.querySelector("#squaads-drag-handle");
    if (primaryButton && actionDisabled) {
      primaryButton.style.cursor = "default";
      primaryButton.style.opacity = "0.95";
    }
    if (primaryButton && actionHandler) {
      primaryButton.addEventListener("click", actionHandler);
    }
    dismiss?.addEventListener("click", () => this.collapse());
    dragHandle?.addEventListener("pointerdown", (event) => this.beginDrag(event));
    this.applyPosition();
    this.syncVisualState();
  }
  async checkStatus(passive = false) {
    if (this.statusRequestInFlight)
      return;
    this.statusRequestInFlight = true;
    if (!passive) {
      this.setState({ type: "checking" });
    }
    let res;
    try {
      res = await send({
        type: "CHECK_STATUS",
        meetingUrl: this.meetingUrl,
        provider: this.provider
      });
    } finally {
      this.statusRequestInFlight = false;
    }
    if (this.isInactive())
      return;
    if (!res.ok) {
      const error = res.error;
      if (error.toLowerCase().includes("not configured")) {
        this.setState({ type: "not_configured" });
      } else {
        this.setState({ type: "error", message: error });
      }
      return;
    }
    const status = res.data;
    if (!status.active || !status.meeting) {
      this.setState({ type: "idle" });
      return;
    }
    this.setState({
      type: "active",
      meetingId: status.meeting.id,
      status: status.meeting.status
    });
    if (TRACKABLE_STATUSES.includes(status.meeting.status)) {
      this.subscribe(status.meeting.id);
    }
  }
  async invite() {
    if (this.isInactive())
      return;
    this.setState({ type: "inviting" });
    const res = await send({
      type: "INVITE_BOT",
      meetingUrl: this.meetingUrl,
      provider: this.provider
    });
    if (this.isInactive())
      return;
    if (!res.ok) {
      const error = res.error;
      this.setState({ type: "error", message: error });
      return;
    }
    const data = res.data;
    this.setState({ type: "active", meetingId: data.meetingId, status: "pending" });
    this.subscribe(data.meetingId);
  }
  collapse() {
    if (this.isInactive())
      return;
    this.collapsed = true;
    this.mount();
    this.scheduleIdleVisuals();
  }
  expand() {
    if (this.isInactive())
      return;
    this.collapsed = false;
    this.mount();
    this.bringToFront();
  }
}

// src/shared/logger.ts
var PREFIX = "[squaads-ext]";
function logInfo(message, meta) {
  if (meta !== undefined) {
    console.log(`${PREFIX} ${message}`, meta);
    return;
  }
  console.log(`${PREFIX} ${message}`);
}

// src/content/content.ts
var widget = null;
var lastUrl = "";
var lastMeetingKey = "";
async function refreshForUrl(url) {
  const adapter = pickAdapter(url);
  if (!adapter) {
    lastUrl = url;
    lastMeetingKey = "";
    widget?.destroy();
    widget = null;
    return;
  }
  const meetingUrl = adapter.getMeetingUrl(url);
  if (!meetingUrl || !adapter.isInsideActiveMeeting()) {
    lastUrl = url;
    lastMeetingKey = "";
    widget?.destroy();
    widget = null;
    return;
  }
  const key = `${adapter.provider}:${meetingUrl}`;
  const sameMeeting = widget && key === lastMeetingKey;
  if (sameMeeting) {
    lastUrl = url;
    widget.sync();
    return;
  }
  if (widget) {
    widget.destroy();
    widget = null;
  }
  widget = new MeetingWidget(meetingUrl, adapter.provider);
  lastUrl = url;
  lastMeetingKey = key;
  logInfo("widget mounted", { provider: adapter.provider, meetingUrl });
  await widget.bootstrap();
}
function start() {
  refreshForUrl(window.location.href);
  setInterval(() => {
    refreshForUrl(window.location.href);
  }, 1500);
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "RESTORE_WIDGET") {
    widget?.restore();
    sendResponse({ ok: true });
    return true;
  }
  if (message.type === "GET_WIDGET_STATE") {
    sendResponse({ ok: true, data: widget ? widget.getViewState() : { collapsed: true } });
    return true;
  }
  return false;
});
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", start);
} else {
  start();
}
