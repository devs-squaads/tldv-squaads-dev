// src/shared/badge-policy.ts
var BADGE_ERROR_STATUSES = [
  "error",
  "transcription_error",
  "admission_timeout",
  "rejected"
];
function resolveBadgeState(status) {
  if (status === "recording")
    return "recording";
  if (status !== null && BADGE_ERROR_STATUSES.includes(status))
    return "error";
  return "clear";
}

// src/shared/constants.ts
var DEFAULT_SETTINGS = {
  apiBaseUrl: "",
  apiToken: "",
  connectionToken: "",
  extensionAccessToken: "",
  extensionAccessTokenExpiresAt: "",
  linkedAccountEmail: "",
  connectedAt: "",
  defaultBotName: "Squaads Assistant",
  defaultDurationMinutes: 60
};
var SEARCH_POLL_INTERVAL_MS = 2000;
var ACTIVE_STATUSES = [
  "pending",
  "joining",
  "waiting_admission",
  "recording",
  "transcribing",
  "summarizing"
];
var TRACKABLE_STATUSES = [...ACTIVE_STATUSES, "transcription_error"];
var STATUS_LABELS = {
  pending: "Queued",
  joining: "Joining",
  waiting_admission: "Waiting admission",
  recording: "Recording",
  transcribing: "Transcribing",
  summarizing: "Summarizing",
  completed: "Completed",
  admission_timeout: "Admission timeout",
  rejected: "Rejected",
  error: "Error",
  transcription_error: "Transcription error"
};

// src/shared/meeting-url.ts
function detectMeetingProvider(url) {
  const lower = url.toLowerCase();
  if (lower.includes("meet.google.com"))
    return "google-meet";
  if (lower.includes("teams.microsoft.com"))
    return "microsoft-teams";
  if (lower.includes("zoom.us") || lower.includes(".zoom.com"))
    return "zoom";
  return null;
}
function normalizeMeetingUrl(url, provider) {
  try {
    const parsed = new URL(url.trim());
    parsed.hash = "";
    if (provider === "google-meet") {
      const match = parsed.href.match(/https:\/\/meet\.google\.com\/[a-z]{3}-[a-z]{4}-[a-z]{3}/i);
      return match ? match[0].toLowerCase() : null;
    }
    parsed.protocol = "https:";
    parsed.hostname = parsed.hostname.toLowerCase();
    parsed.pathname = parsed.pathname.replace(/\/+$/, "");
    return parsed.toString();
  } catch {
    return null;
  }
}

// src/shared/logger.ts
var PREFIX = "[squaads-ext]";
function logInfo(message, meta) {
  if (meta !== undefined) {
    console.log(`${PREFIX} ${message}`, meta);
    return;
  }
  console.log(`${PREFIX} ${message}`);
}
function logWarn(message, meta) {
  if (meta !== undefined) {
    console.warn(`${PREFIX} ${message}`, meta);
    return;
  }
  console.warn(`${PREFIX} ${message}`);
}

// src/shared/origin.ts
function normalizeOrigin(input) {
  try {
    const parsed = new URL(input.trim());
    const protocol = parsed.protocol.toLowerCase();
    const hostname = parsed.hostname.toLowerCase();
    const port = parsed.port;
    const isDefaultPort = protocol === "https:" && port === "443" || protocol === "http:" && port === "80";
    const host = port && !isDefaultPort ? `${hostname}:${port}` : hostname;
    return `${protocol}//${host}`;
  } catch {
    return "";
  }
}
function toHostPermissionPattern(baseUrl) {
  const origin = normalizeOrigin(baseUrl);
  return origin ? `${origin}/*` : "";
}
function getConnectableSiteContext(url) {
  if (!url) {
    return {
      origin: "",
      eligible: false,
      reason: "Open the Squaads dashboard tab where you generated the token, then try again."
    };
  }
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return {
      origin: "",
      eligible: false,
      reason: "This tab cannot be used for connection. Open the Squaads dashboard first."
    };
  }
  if (!["http:", "https:"].includes(parsed.protocol)) {
    return {
      origin: "",
      eligible: false,
      reason: "Only a Squaads web tab can finish connection. Browser internal pages are not supported."
    };
  }
  const provider = detectMeetingProvider(url);
  if (provider && normalizeMeetingUrl(url, provider)) {
    return {
      origin: "",
      eligible: false,
      reason: "You are on a meeting tab. Return to the Squaads dashboard tab where you generated the token."
    };
  }
  if (parsed.hostname === "chromewebstore.google.com" || parsed.hostname === "chrome.google.com" && parsed.pathname.startsWith("/webstore")) {
    return {
      origin: "",
      eligible: false,
      reason: "Return to the Squaads dashboard tab after visiting the Chrome Web Store."
    };
  }
  const origin = normalizeOrigin(parsed.toString());
  return {
    origin,
    eligible: Boolean(origin),
    reason: origin ? `Current site ready: ${origin}` : "Open the Squaads dashboard tab before connecting."
  };
}

// src/popup/meeting-entry-policy.ts
function getPopupMeetingEntryDecision(status) {
  const keepSubscription = TRACKABLE_STATUSES.includes(status);
  return {
    keepSubscription,
    allowInvite: !keepSubscription
  };
}

// src/popup/popup.ts
var STATUS_PORT_NAME = "squaads-status";
var connectionToken = document.getElementById("connection-token");
var botName = document.getElementById("bot-name");
var duration = document.getElementById("duration");
var connectButton = document.getElementById("connect-extension");
var showOverviewButton = document.getElementById("show-overview");
var showSettingsButton = document.getElementById("show-settings");
var overviewPanel = document.getElementById("overview-panel");
var settingsPanel = document.getElementById("settings-panel");
var saveButton = document.getElementById("save-settings");
var inviteButton = document.getElementById("invite-now");
var restoreWidgetButton = document.getElementById("restore-widget");
var actions = document.getElementById("meeting-actions");
var refreshButton = document.getElementById("refresh-status");
var feedback = document.getElementById("feedback");
var meetingStatus = document.getElementById("meeting-status");
var meetingMeta = document.getElementById("meeting-meta");
var runtimeStatus = document.getElementById("meeting-runtime-status");
var connectionStatusCard = document.getElementById("connection-status-card");
var connectionStatusTitle = document.getElementById("connection-status-title");
var connectionStatusCopy = document.getElementById("connection-status-copy");
var connectionSiteCopy = document.getElementById("connection-site-copy");
var currentMeetingUrl = null;
var currentProvider = null;
var currentMeetingId = null;
var currentTabId = null;
var currentConnectOrigin = "";
var currentConnectReason = "Open the Squaads dashboard tab before connecting.";
var currentConnectEligible = false;
var searchTimer = null;
var statusPort = null;
var subscribedMeetingId = null;
var cachedSettings = { ...DEFAULT_SETTINGS };
var currentTokenPreview = null;
var transientConnectionState = null;
var transientConnectionDetail = "";
function send(message) {
  return chrome.runtime.sendMessage(message);
}
function isExpired(isoTimestamp) {
  if (!isoTimestamp)
    return false;
  const parsed = Date.parse(isoTimestamp);
  if (Number.isNaN(parsed))
    return false;
  return parsed <= Date.now();
}
function decodeBase64UrlSegment(segment) {
  const normalized = segment.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
  const binary = atob(padded);
  const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}
function parseLinkTokenPreview(token) {
  const trimmed = token.trim();
  if (!trimmed)
    return null;
  const segments = trimmed.split(".");
  const payloadSegment = segments[0];
  if (!payloadSegment)
    return null;
  try {
    const payload = JSON.parse(decodeBase64UrlSegment(payloadSegment));
    if (payload.type !== "extension_link" || !payload.baseUrl || !payload.email || !payload.exp) {
      return null;
    }
    const expiresAt = new Date(payload.exp * 1000).toISOString();
    return {
      email: payload.email,
      baseUrl: normalizeOrigin(payload.baseUrl),
      expiresAt,
      expired: payload.exp * 1000 <= Date.now()
    };
  } catch {
    return null;
  }
}
function clearTransientConnectionState() {
  if (transientConnectionState === "connecting")
    return;
  transientConnectionState = null;
  transientConnectionDetail = "";
}
function setTransientConnectionState(state, detail = "") {
  transientConnectionState = state;
  transientConnectionDetail = detail;
}
function setInviteAvailability(enabled) {
  inviteButton.disabled = !enabled;
}
function setInviteVisibility(visible) {
  inviteButton.hidden = !visible;
  actions.classList.toggle("actions--single", !visible);
}
function setRestoreWidgetVisibility(visible) {
  restoreWidgetButton.hidden = !visible;
}
function syncBadge(state) {
  send({ type: "SET_BADGE", state });
}
function setActiveView(view) {
  const showOverview = view === "overview";
  overviewPanel.hidden = !showOverview;
  settingsPanel.hidden = showOverview;
  showOverviewButton.classList.toggle("view-toggle__button--active", showOverview);
  showSettingsButton.classList.toggle("view-toggle__button--active", !showOverview);
  showOverviewButton.setAttribute("aria-selected", String(showOverview));
  showSettingsButton.setAttribute("aria-selected", String(!showOverview));
}
function getTargetOrigin() {
  return currentConnectOrigin;
}
function getSecureSessionState(settings) {
  if (!settings.extensionAccessToken || !settings.linkedAccountEmail) {
    return "none";
  }
  return isExpired(settings.extensionAccessTokenExpiresAt) ? "expired" : "valid";
}
function renderConnectionStatus() {
  const secureSessionState = getSecureSessionState(cachedSettings);
  const targetOrigin = currentConnectOrigin;
  let state = "not-connected";
  let title = "Not connected yet";
  let copy = "Paste a temporary connection token from the Squaads dashboard to connect this extension securely.";
  if (transientConnectionState) {
    state = transientConnectionState;
    title = transientConnectionState === "connecting" ? "Connecting to current site" : "Connection requires attention";
    copy = transientConnectionDetail || copy;
  } else if (secureSessionState === "valid") {
    state = "connected";
    title = `Connected as ${cachedSettings.linkedAccountEmail}`;
    copy = cachedSettings.extensionAccessTokenExpiresAt ? `Secure extension session active until ${new Date(cachedSettings.extensionAccessTokenExpiresAt).toLocaleString()}. Paste a new token only if you want to reconnect.` : "Secure extension session active.";
  } else if (secureSessionState === "expired") {
    state = "session-expired";
    title = "Session expired";
    copy = "Your secure extension session expired. Go back to the Squaads dashboard, generate a new token, and reconnect from this site.";
  } else if (currentTokenPreview?.expired) {
    state = "token-expired";
    title = "Connection token expired";
    copy = "This temporary token expired before connection. Generate a fresh token from the dashboard and paste it again.";
  } else if (connectionToken.value.trim() && !currentTokenPreview) {
    state = "connect-error";
    title = "Malformed connection token";
    copy = "This token could not be decoded by the extension. Generate a fresh token from the Squaads dashboard and paste it again.";
  } else if (currentTokenPreview) {
    if (!targetOrigin) {
      state = "unsupported-site";
      title = "Open the correct dashboard tab";
      copy = currentConnectReason;
    } else if (currentTokenPreview.baseUrl !== targetOrigin) {
      state = "wrong-site";
      title = "Wrong site for this token";
      copy = `This token was generated for ${currentTokenPreview.baseUrl}. Open that same Squaads site before connecting.`;
    } else {
      state = "ready";
      title = "Ready to connect";
      copy = `Token ready for ${currentTokenPreview.email}. Click Connect to Current Site to bind this extension to ${targetOrigin}.`;
    }
  }
  connectionStatusCard.className = `connection-status connection-status--${state}`;
  connectionStatusTitle.textContent = title;
  connectionStatusCopy.textContent = copy;
  connectionSiteCopy.textContent = currentConnectReason;
  const canAttemptConnect = (state === "ready" || state === "connected") && Boolean(currentTokenPreview);
  connectButton.disabled = !canAttemptConnect || transientConnectionState === "connecting";
  connectButton.textContent = transientConnectionState === "connecting" ? "Connecting..." : "Connect to Current Site";
}
function formatMeetingMeta(provider, meetingUrl) {
  const compactUrl = meetingUrl.replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/^meet\.google\.com\//, "Google Meet · ").replace(/^teams\.microsoft\.com\//, "Microsoft Teams · ").replace(/^([^.]+\.)?zoom\.(us|com)\//, "Zoom · ");
  return `Live sync on ${provider.replace("-", " ")} · ${compactUrl}`;
}
async function sendToActiveTab(message) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (typeof tab?.id !== "number")
    return null;
  try {
    return await chrome.tabs.sendMessage(tab.id, message);
  } catch {
    return null;
  }
}
async function refreshWidgetState() {
  const response = await sendToActiveTab({ type: "GET_WIDGET_STATE" });
  if (!response?.ok || !("data" in response)) {
    setRestoreWidgetVisibility(false);
    return;
  }
  const state = response.data;
  setRestoreWidgetVisibility(state.collapsed);
}
function resetMeetingControls() {
  unsubscribeFromMeeting();
  stopSearching();
  setInviteVisibility(false);
  setInviteAvailability(false);
  setRestoreWidgetVisibility(false);
  syncBadge("clear");
}
function applyMeetingEntry(entry) {
  if (!entry) {
    currentMeetingId = null;
    runtimeStatus.textContent = "Status: idle";
    unsubscribeFromMeeting();
    setInviteVisibility(true);
    setInviteAvailability(true);
    syncBadge("clear");
    startSearching();
    refreshWidgetState();
    return;
  }
  currentMeetingId = entry.meetingId;
  runtimeStatus.textContent = `Status: ${STATUS_LABELS[entry.status]}`;
  syncBadge(resolveBadgeState(entry.status));
  const decision = getPopupMeetingEntryDecision(entry.status);
  if (decision.keepSubscription) {
    setInviteVisibility(false);
    setInviteAvailability(false);
    subscribeToMeeting(entry.meetingId);
    refreshWidgetState();
    return;
  }
  unsubscribeFromMeeting();
  setInviteVisibility(true);
  setInviteAvailability(decision.allowInvite);
  refreshWidgetState();
}
function syncTokenPreviewFromInput() {
  currentTokenPreview = parseLinkTokenPreview(connectionToken.value);
  clearTransientConnectionState();
  renderConnectionStatus();
}
async function loadSettings() {
  const response = await send({ type: "GET_SETTINGS" });
  if (!response.ok)
    return;
  const settings = response.data;
  cachedSettings = settings;
  connectionToken.value = settings.connectionToken;
  botName.value = settings.defaultBotName;
  duration.value = String(settings.defaultDurationMinutes);
  syncTokenPreviewFromInput();
}
async function saveSettings() {
  const settings = {
    ...cachedSettings,
    connectionToken: connectionToken.value.trim(),
    defaultBotName: botName.value.trim() || DEFAULT_SETTINGS.defaultBotName,
    defaultDurationMinutes: Number(duration.value) || DEFAULT_SETTINGS.defaultDurationMinutes
  };
  const response = await send({ type: "SAVE_SETTINGS", settings });
  feedback.textContent = response.ok ? "Settings saved." : response.error;
  if (response.ok) {
    cachedSettings = settings;
    setActiveView("overview");
    syncTokenPreviewFromInput();
  }
  await refreshRuntimeStatus();
}
async function connectFromPopup() {
  const trimmedToken = connectionToken.value.trim();
  const parsedToken = parseLinkTokenPreview(trimmedToken);
  if (!trimmedToken) {
    feedback.textContent = "Paste the connection token from the Squaads web app first.";
    setTransientConnectionState("connect-error", "Paste the temporary token from the dashboard before connecting.");
    renderConnectionStatus();
    return;
  }
  if (!parsedToken) {
    feedback.textContent = "This connection token is malformed. Generate a new one from the dashboard.";
    setTransientConnectionState("connect-error", "The pasted token is not valid. Generate a fresh one from the Squaads dashboard.");
    renderConnectionStatus();
    return;
  }
  if (parsedToken.expired) {
    feedback.textContent = "This connection token expired. Generate a new one from the dashboard.";
    currentTokenPreview = parsedToken;
    clearTransientConnectionState();
    renderConnectionStatus();
    return;
  }
  const targetOrigin = getTargetOrigin();
  if (!targetOrigin) {
    feedback.textContent = currentConnectReason;
    setTransientConnectionState("unsupported-site", currentConnectReason);
    renderConnectionStatus();
    return;
  }
  if (parsedToken.baseUrl !== targetOrigin) {
    feedback.textContent = `Open ${parsedToken.baseUrl} before connecting this token.`;
    setTransientConnectionState("wrong-site", `This token belongs to ${parsedToken.baseUrl}. Open that same Squaads dashboard tab and try again.`);
    renderConnectionStatus();
    return;
  }
  const hostPattern = toHostPermissionPattern(targetOrigin);
  let hostPermissionGranted = false;
  try {
    hostPermissionGranted = hostPattern ? await chrome.permissions.request({ origins: [hostPattern] }) : false;
  } catch {
    hostPermissionGranted = false;
  }
  if (!hostPermissionGranted) {
    const permissionMessage = `This extension needs your permission to reach ${targetOrigin}. Click Connect to Current Site again and choose Allow.`;
    feedback.textContent = permissionMessage;
    setTransientConnectionState("connect-error", permissionMessage);
    renderConnectionStatus();
    return;
  }
  setTransientConnectionState("connecting", `Connecting this extension to ${targetOrigin}...`);
  renderConnectionStatus();
  feedback.textContent = "Connecting extension...";
  const response = await send({
    type: "CONNECT_EXTENSION",
    linkToken: trimmedToken
  });
  if (!response.ok) {
    const errorText = response.error;
    feedback.textContent = errorText;
    setTransientConnectionState("connect-error", errorText);
    renderConnectionStatus();
    return;
  }
  const data = response.data;
  cachedSettings = {
    ...cachedSettings,
    apiBaseUrl: data.apiBaseUrl,
    connectionToken: "",
    extensionAccessToken: data.extensionAccessToken,
    extensionAccessTokenExpiresAt: data.expiresAt,
    linkedAccountEmail: data.linkedAccountEmail,
    connectedAt: new Date().toISOString()
  };
  connectionToken.value = "";
  currentTokenPreview = null;
  setTransientConnectionState(null);
  renderConnectionStatus();
  feedback.textContent = `Extension connected successfully for ${data.linkedAccountEmail}.`;
}
async function inspectCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTabId = typeof tab?.id === "number" ? tab.id : null;
  const url = tab?.url || "";
  const connectContext = getConnectableSiteContext(url);
  currentConnectOrigin = connectContext.origin;
  currentConnectReason = connectContext.reason;
  currentConnectEligible = connectContext.eligible;
  clearTransientConnectionState();
  renderConnectionStatus();
  const provider = detectMeetingProvider(url);
  if (!provider) {
    currentMeetingUrl = null;
    currentProvider = null;
    currentMeetingId = null;
    currentTabId = null;
    resetMeetingControls();
    refreshButton.disabled = true;
    meetingStatus.textContent = "Current tab is not Meet, Teams, or Zoom.";
    meetingMeta.textContent = "Open a supported meeting to enable runtime controls.";
    runtimeStatus.textContent = currentConnectEligible ? `Connection site ready: ${currentConnectOrigin}` : "";
    return;
  }
  const normalized = normalizeMeetingUrl(url, provider);
  if (!normalized) {
    currentMeetingUrl = null;
    currentProvider = null;
    currentMeetingId = null;
    currentTabId = null;
    resetMeetingControls();
    refreshButton.disabled = true;
    meetingStatus.textContent = "Could not normalize meeting URL for this tab.";
    meetingMeta.textContent = "This tab was detected, but the meeting URL could not be normalized safely.";
    runtimeStatus.textContent = "";
    return;
  }
  currentProvider = provider;
  currentMeetingUrl = normalized;
  setInviteVisibility(true);
  setInviteAvailability(true);
  setRestoreWidgetVisibility(false);
  refreshButton.disabled = false;
  meetingStatus.textContent = `Detected ${provider} meeting.`;
  meetingMeta.textContent = formatMeetingMeta(provider, normalized);
  logInfo("popup detected active meeting", { provider, currentMeetingUrl });
  await refreshRuntimeStatus();
}
async function inviteFromPopup() {
  if (!currentMeetingUrl || !currentProvider)
    return;
  feedback.textContent = "Inviting bot...";
  setInviteVisibility(false);
  inviteButton.disabled = true;
  const response = await send({
    type: "INVITE_BOT",
    meetingUrl: currentMeetingUrl,
    provider: currentProvider
  });
  if (!response.ok) {
    const error = response.error;
    logWarn("popup invite failed", { error });
    feedback.textContent = error;
    setInviteVisibility(true);
    inviteButton.disabled = false;
    return;
  }
  const data = response.data;
  logInfo("popup invite queued", data);
  feedback.textContent = `Bot queued successfully for ${data.provider}.`;
  currentMeetingId = data.meetingId;
  runtimeStatus.textContent = `Status: ${STATUS_LABELS.pending}`;
  subscribeToMeeting(data.meetingId);
  setInviteAvailability(false);
  await refreshWidgetState();
}
async function restoreWidgetFromPopup() {
  const response = await sendToActiveTab({ type: "RESTORE_WIDGET" });
  if (!response?.ok) {
    feedback.textContent = "Could not restore floating widget in this tab.";
    return;
  }
  feedback.textContent = "Floating widget restored.";
  await refreshWidgetState();
}
async function refreshRuntimeStatus() {
  if (!currentMeetingUrl || !currentProvider)
    return;
  const response = await send({
    type: "CHECK_STATUS",
    meetingUrl: currentMeetingUrl,
    provider: currentProvider
  });
  if (!response.ok) {
    const error = response.error;
    unsubscribeFromMeeting();
    currentMeetingId = null;
    syncBadge("clear");
    runtimeStatus.textContent = error;
    setInviteVisibility(true);
    setInviteAvailability(true);
    return;
  }
  const data = response.data;
  if (!data.active || !data.meeting) {
    applyMeetingEntry(null);
    return;
  }
  applyMeetingEntry({
    meetingId: data.meeting.id,
    meetingUrl: data.normalizedUrl || currentMeetingUrl,
    provider: currentProvider,
    status: data.meeting.status
  });
}
function startSearching() {
  if (searchTimer)
    return;
  searchTimer = setInterval(() => {
    refreshRuntimeStatus();
  }, SEARCH_POLL_INTERVAL_MS);
}
function stopSearching() {
  if (!searchTimer)
    return;
  clearInterval(searchTimer);
  searchTimer = null;
}
function subscribeToMeeting(meetingId) {
  if (subscribedMeetingId === meetingId && statusPort)
    return;
  unsubscribeFromMeeting();
  stopSearching();
  subscribedMeetingId = meetingId;
  statusPort = chrome.runtime.connect({ name: STATUS_PORT_NAME });
  statusPort.onMessage.addListener((msg) => {
    if (msg.type !== "MEETING_UPDATE")
      return;
    if (msg.meetingId !== subscribedMeetingId)
      return;
    applyPortUpdate(msg.status);
  });
  statusPort.onDisconnect.addListener(() => {
    statusPort = null;
  });
  statusPort.postMessage({ type: "SUBSCRIBE", meetingId, provider: currentProvider });
}
function unsubscribeFromMeeting() {
  subscribedMeetingId = null;
  if (!statusPort)
    return;
  statusPort.disconnect();
  statusPort = null;
}
function applyPortUpdate(status) {
  if (!currentMeetingUrl || !currentProvider)
    return;
  applyMeetingEntry({
    meetingId: subscribedMeetingId ?? currentMeetingId ?? "",
    meetingUrl: currentMeetingUrl,
    provider: currentProvider,
    status
  });
}
chrome.tabs.onActivated.addListener(() => {
  inspectCurrentTab();
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (currentTabId !== null && tabId !== currentTabId)
    return;
  if (!(changeInfo.url || changeInfo.status === "complete"))
    return;
  inspectCurrentTab();
});
showOverviewButton.addEventListener("click", () => setActiveView("overview"));
showSettingsButton.addEventListener("click", () => setActiveView("settings"));
saveButton.addEventListener("click", () => void saveSettings());
connectButton.addEventListener("click", () => void connectFromPopup());
inviteButton.addEventListener("click", () => void inviteFromPopup());
restoreWidgetButton.addEventListener("click", () => void restoreWidgetFromPopup());
refreshButton.addEventListener("click", () => void refreshRuntimeStatus());
connectionToken.addEventListener("input", () => syncTokenPreviewFromInput());
document.addEventListener("DOMContentLoaded", () => {
  setActiveView("overview");
  setInviteVisibility(false);
  setRestoreWidgetVisibility(false);
  renderConnectionStatus();
  loadSettings();
  inspectCurrentTab();
});
